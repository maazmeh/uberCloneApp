  //State all Global Variables here, like Google API's etc
  //Sets a global price for All kind of Rides
  export let costPerKmBike = 90;
  export let costPerKmCity = 90;
  export let costPerKmCourier = 90;
  export let costPerKmFreight = 90;
  export let baseCost = 1000;

  export let APIKey = 'AIzaSyB7aeI9X3sqWjCUvFNbL0jbX11tKEEJfOs';


  export const firebaseConfig = {
    apiKey: "AIzaSyD8Ft9oRMA1E0RPmKQ6tpy8_vb0DGwgRFE",
    authDomain: "nairide-e0a9c.firebaseapp.com",
    projectId: "nairide-e0a9c",
    storageBucket: "nairide-e0a9c.appspot.com",
    messagingSenderId: "284530663860",
    appId: "1:284530663860:android:a89bf5ae3f7744137d12e1",
  };